// Show the age verification modal on page load
window.onload = function() {
    document.getElementById('age-verification-modal').style.display = 'flex';
}

// Handle "Yes, I'm 21+" button click
document.getElementById('age-verification-yes').onclick = function() {
    alert('Checking Your identity...')
    alert('Verification Sucessfully!')
    window.location.href = 'preload7.html'; // Redirect to html1.index
    
}

// Handle "No, I'm under 21" button click
document.getElementById('age-verification-no').onclick = function() {
    alert("You must be 21 or older to access this site.");
    window.location.href = 'https://www.google.com'; // Redirect to a different page or exit
}
