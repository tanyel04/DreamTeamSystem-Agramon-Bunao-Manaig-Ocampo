// Function to hide preloader and redirect to index1.html
window.onload = function() {
    // Show the preloader (already visible by default on page load)
    setTimeout(function() {
        // Hide the preloader after 3 seconds (3000 milliseconds)
        document.getElementById('preloader').style.display = 'none';
        
        // Redirect to index1.html
        window.location.href = 'Age Verification.html';
    }, 3000); // Adjust the delay time (currently 3 seconds)
};

